#### Workaround to get **vue-devtools** in Safari.

1. Clone this repo
2. `npm install` (Or `yarn install` if you are using yarn as the package manager)
3. `npm run build:safari`
4. Open Safari preferences -> Advanced -> Show Develop menu in menu bar
5. Open Develop -> Show Extension Builder
6. Click the plus button in the bottom left and select Add Extension...
7. Select shells/safari/Vue.js devtools.safariextension
8. Click Install in the top right
